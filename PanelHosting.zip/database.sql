-- Script SQL de tablas (resumen)
CREATE TABLE users (...);
CREATE TABLE planes (...);
...