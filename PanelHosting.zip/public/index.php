<?php
// Bootstrap del panel
require '../routes/web.php';